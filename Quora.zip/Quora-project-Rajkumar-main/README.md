# Quora-project

![download](https://user-images.githubusercontent.com/96281694/161429982-780b3c52-19cb-493f-9feb-b5ade953260d.png)

<h4>Quora is a place to gain and share knowledge</h4>. <br>It is a platform to ask question and connect with people who contribute unique insights and quality answers.<br>

# Contributors
1. Abhishek Satpute.
2. Haleema Zehera.
3. Gaurav Kashyap.
4. Rajkumar Yadav.
5. Tarun Rakhunde.<br><br>
These is a collaborative project of 5 team members buid in 6 days.

# Tech Stack  used 
- CSS
- HTML
- Javascript
- React
- Redux
- ExpressJS
- NodeJS
- MongoDB
- Firebase.
# Images
![Screenshot (1144)](https://user-images.githubusercontent.com/93375598/161431284-3ea74c96-256c-4005-b05e-9b33a0fca45a.png)


![Screenshot (1145)](https://user-images.githubusercontent.com/93375598/161431341-c61d8b8d-4ab0-4b6a-8e71-730059fd5cda.png)

![Screenshot (1146)](https://user-images.githubusercontent.com/93375598/161431352-c11cd7d7-52a7-42ad-b6bb-c97c24ff1202.png)

![Screenshot (1142)](https://user-images.githubusercontent.com/93375598/161431363-3d611925-95a2-472f-8ecb-b1b854a1d032.png)

![Screenshot (1143)](https://user-images.githubusercontent.com/93375598/161431385-e0a46238-e46d-433f-b2e0-afe61fec1516.png)

# Challenge we faced
- Merging each other code on Github<br>
- Read others code and make changes to it<br>
- Build and write APIS and deploy it to the MongoDB server<br>
- Edge case problem solving<br>

# Blog
https://medium.com/@tarunrakhunde/quora-clone-project-9ae321356895

# Thanking note
If you are still here and reading these we fell so glad. Thank you for giving time to visit our project!!!.

